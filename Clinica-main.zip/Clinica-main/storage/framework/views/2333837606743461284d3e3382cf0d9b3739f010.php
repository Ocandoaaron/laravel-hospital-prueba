<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">

     <!--Import Google Icon Font-->
     <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
            
     

    <title>Document</title>
</head>
<body>
    
        <div class="row">
            <div class="col s12">
                <div style="text-align:center;"> <h3><a style="text-decoration:none;"
                 href="https://www.zeitverschiebung.net/es/country/do"><br /></a></h3>
                <iframe src="https://www.zeitverschiebung.net/clock-widget-iframe-v2?language=es&size=medium&timezone=America%2FSanto_Domingo" width="100%"
                 height="115" frameborder="0" seamless></iframe> </div>
            </div>
        </div>

        

        <div class="container section">
          <div class="row">
           
  
            <div class="col m4 s4">
             
                     
          </div>
  
  
            <div class="col m4 s12">
            
              <img class="responsive-img" src="img/Clinica.png">
           
          </div>
  
         
            
        </div>
        </div>



        <div class="row">
          <div class="col s12">
            <center><a href="<?php echo e(route('principal.sistema')); ?>" class="waves-effect waves-light btn-large red darken-1"><i class="material-icons left">local_hospital</i><b>ACCEDER</b></a></center>
          </div>
      </div>

            

 <!-- Compiled and minified JavaScript -->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

</body>
</html><?php /**PATH C:\xampp1\htdocs\FirebaseCrud\resources\views/panel.blade.php ENDPATH**/ ?>